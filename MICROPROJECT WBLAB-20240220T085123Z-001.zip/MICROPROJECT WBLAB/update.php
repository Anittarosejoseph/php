<?php 
$con=new mysqli("localhost","root","","products");
if($con->connect_error)
{
    die("connection failed".$con->connect_error);
}
    if (isset($_POST['update'])) {

        $name = $_POST['name'];
        $email = $_POST['email'];
        $user_id = $_POST['id'];
        $sql = "UPDATE `registration` SET `name`='$name',`email`='$email' WHERE `id`='$user_id'"; 
        // 'UPDATE `registration` SET `` = '4567890', `confirmpassword` = '456780', `email` = 'asdd@gmail.com' WHERE `registration`.`id` = 567922;
        $result = $con->query($sql); 

        if ($result == TRUE) {

            header('Location: view.php');

        }else{

            echo "Error:" . $sql . "<br>" . $con->error;

        }

    } 

if (isset($_GET['id'])) {

    $user_id = $_GET['id']; 

    $sql = "SELECT * FROM `registration` WHERE `id`='$user_id'";

    $result = $con->query($sql); 

    if ($result->num_rows > 0) {        

        while ($row = $result->fetch_assoc()) {

            $name = $row['name'];
            $email = $row['email'];

            $id = $row['id'];

        } 

    ?>

        <h2>User Update Form</h2>

        <form action="" method="post">

          <fieldset>

            <legend>Personal information:</legend>

            First name:<br>

            <input type="text" name="name" value="<?php echo $name; ?>">

            <input type="hidden" name="id" value="<?php echo $id; ?>"> 

            <br>

            Email:<br>

            <input type="email" name="email" value="<?php echo $email; ?>">

           <br>

            <input type="submit" value="Update" name="update">

          </fieldset>

        </form> 

        </body>

        </html> 

    <?php

    } else{ 

        header('Location: view.php');

    } 
    
}
?>