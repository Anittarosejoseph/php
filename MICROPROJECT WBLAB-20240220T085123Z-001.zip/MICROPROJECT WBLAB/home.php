<html>
    <head>
     <title>Homepage</title>
        <style>
            body{
                background-image:url('big.png');
                background-repeat: no-repeat;
                 background-attachment: fixed;
                  background-size: cover;
            }
            a{
                font-size: 20px;
                padding:0px;
            }
            p{
    color:brown;
    font-style: oblique;
    text-align: center;
    font-size:small;
}
h1
{
    font-weight: 300;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    color:red;
    text-align: center;
}
h3{
    color:blueviolet;
    font-size: small;
    font-family:'Courier New', Courier, monospace ;
    text-align: center;
}
.center {
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;
  }
            .logo {
	float: left; 
	    display: inline-block;
	width: 300px;
}
            .menu {
	padding: 0; 
	margin: 0; 
	overflow: hidden;  
	width: 900px;
}
.menu ul {
	float:right; 
}
.menu ul li  {
	list-style: none; 
	    display:inline-block;
        padding: 4px 20px;
	float: left;  
}
        </style>
    </head>
    <body>
        <div>
            <img src="big.png" alt="image" width="50" height="50">
            <div class="menu">
                <ul>
                   <li><a href="home.php">Home</a></li>
                   <li><a href="contact.php">Contact Us</a></li>
                   <li><a href="loginpage.php">Sign in</a><tr>
                    <li><a href="Register.php">Register</a><tr></tr>
                   </tr>
                </ul>
             </div>
             <H1>FIRSTCRY</H1>
             <h3>big store for little ones</h3>
            <img src="big.png" width="50" height="300" class="center">
           <p>FirstCry.com - Asia's Largest Online Baby and Kids Store, is India's largest online shop for new mom and baby products, offering top of the line discounts on renowned national & International brands. Some of the most reputed brands available on FirstCry.com include Chicco, Graco, BSA, Johnson & Johnson, Medela, Pigeon, Fisher - Price, FunSkool, Lego, Disney & Barbie. FirstCry.com offers the widest range to chose from, boasting of over 2 Lakh Baby & Kids products. Customers can avail benefits of free Shipping as well as CoD(Cash on Delivery) on purchase from the website. © 2010-2023  www.FirstCry.com. All rights reserved. This website can be best viewed in resolution width of 1024 and above.</p>
    </body>
    </html>