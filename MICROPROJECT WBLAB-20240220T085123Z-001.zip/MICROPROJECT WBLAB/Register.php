<html>
    <head>
        <title>Registrationform</title>
        <style>
            body{
                background-image:url('background.jfif');
                background-repeat: no-repeat;
                 background-attachment: fixed;
                background-size:cover;
            }
            form{
                border:1px soild;
                padding:20px;
                font: size 50px;;
                color: black;
                text-align: center;
                margin: 0 auto;
            }
        </style>
    </head>
    <body>
        <h1><center>Register Here!!!</center></h1>
        <script>

function validateform()
{
var x=document.myform.name.value;
var y=document.myform.password.value;
var z=document.myform.confirmpassword.value;
var w=document.myform.email.value;
var atposition=w.indexOf("@");
var dotposition=w.lastIndexOf(".");
if(x==null||x=="")
{
alert("The name field shouldn't be blank");
}
else if(y.length<6)
{
alert("password contain atleast 6 characters");
}
else if(y!=z)
{
alert("password not matches");
}
else if(atposition<1||dotposition<atposition+2||dotposition+2>w.length)
{
alert("Enter avalid email address");
}
}
</script>
            <?php
            $con=mysqli_connect("localhost","root","","products");
            if(mysqli_select_db($con,"products"))
            {
            echo 'connection success';
            }
            else
            {
            echo 'connection failed';
            }
            if(isset($_POST['submit']))
            {
            // $id=$_POST['id'];
            $name=$_POST['name'];
            $password=$_POST['password'];
            $confirmpassword=$_POST['confirmpassword'];
            $email=$_POST['email'];
            $sql="INSERT INTO `registration` (`name`, `password`, `confirmpassword`, `email`) VALUES ('$name', '$password', '$confirmpassword', '$email')";  
           $result=$con->query($sql);
            if($result==TRUE)
            {
            echo 'inserted succesfully';
            }
        }
            $sql="select * from registration";
            $result=$con->query($sql);
            ?>
            <br>
            <br>
            <br>
            <br>
            <form name="myform" onsubmit=validateform() method="POST">
            ENTER THE FULL NAME:<input type="text" name="name" value="" ><br><br>
            PASSWORD:<input type="password" name="password" value="" ><br><br>
            CONFIRM PASSWORD:<input type="password" name="confirmpassword" value=""><br><br>
            EMAIL ADDRESS:<input type="text" name="email" ><br><br>
            <input type="submit" name="submit" value="Register">
            <br>
            </form>
        </body>
        </html>

       