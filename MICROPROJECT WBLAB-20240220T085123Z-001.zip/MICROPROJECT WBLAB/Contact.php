<html>
    <head>
        <style>
              body{
                background-image:url('cont.jpg');
                background-repeat: no-repeat;
                 background-attachment: fixed;
                  background-size: cover;
            }
            </style>
    </head>
To raise any order related query, click here <a href="loginpage.php">Login</a> to continue
<h1>CONTACT US</h1>
<h4><b>firstcry@yahoo.com</b></h4>
<a href="#">facebook</a><br>
<a href="#">instagram</a><br>
<a href="#">Twitter</a><br>
</html>

