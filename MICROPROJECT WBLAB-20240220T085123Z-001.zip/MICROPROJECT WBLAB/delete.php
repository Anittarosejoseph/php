<?php 
$con=new mysqli("localhost","root","","products");
if($con->connect_error)
{
    die("connection failed".$con->connect_error);
}

if (isset($_GET['id'])) {

    $user_id = $_GET['id'];

    $sql = "DELETE FROM `registration` WHERE `id`='$user_id'";

     $result = $con->query($sql);

     if ($result == TRUE) {

        echo "Record deleted successfully.";

    }else{

        echo "Error:" . $sql . "<br>" . $con->error;

    }

} 

?>