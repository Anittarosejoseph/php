<html>
    <head>
        <style>
            body{
                background-image:url('login.jfif');
                background-repeat: no-repeat;
                 background-attachment:fixed;
                background-size:cover;
            }
            form{
                border:1px soild;
                padding: 50px;
                text-align: center;
                font-size: large;
                color: black;
                margin: 0 auto;
            }
        </style>
        <title>loginpage</title>
    </head>
    <body>
        <h1 style="color: red;font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;text-align: center;padding-top: 30PX;">LOGIN HERE</h1>
        <script>  
            function validateform()
            { 
            var w=document.myform.email.value;
            var password=document.myform.password.value; 
            var atposition=w.indexOf("@");
            var dotposition=w.lastIndexOf("."); 
            if (atposition<1||dotposition<atposition+2||dotposition+2>w.length)
            {
            alert("Enter avalid email address");
            } 
        else if(password.length<6){  
              alert("Password must be at least 6 characters long.");  
              return false;  
              }  
            }  
            </script>  
            <body>  
            <form name="myform" method="post" onsubmit="validateform()" >  
                EMAIL ADDRESS:<input type="text"name="email"><br><br> 
            PASSWORD: <input type="password" name="password"><br><br>
            <input type="submit" value="LOGIN">  
            <input type="submit" value="CANCEL">
            </form>  
           <p style="text-align: center;"> If you are new here, click here <a href="register.php">Sign up</a> to continue</p>
    </body>
</html>