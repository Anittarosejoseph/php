<?php
$con=mysqli_connect("localhost","root","","products");
if(mysqli_select_db($con,"products"))
{
echo 'connection success';
}
else
{
echo 'connection failed';
}$sql = " SELECT * FROM `registration` " ;
$result=$con->query($sql);
?>
<html>
<head>
<title>view page</title>
</head>
<body>
<div class="container">
<h2>USERS</h2>
<table>
<tr>
<th>name</th>
<th>password</th>
<th>email</th>
</tr>
<?php
if($result->num_rows>0)
{
	while($row=$result->fetch_assoc())
	{
?>
<tr>
<td><?php echo $row['name'];?></td>
<td><?php echo $row['password'];?></td>
<td><?php echo $row['email'];?></td>
<td><a href="update.php?id=<?php echo $row['id'];?>">Edit</a></td>
<td><a href="delete.php?id=<?php echo $row['id'];?>">Delete</a></td>
<?php
	}
}
?>
</table>
</html>